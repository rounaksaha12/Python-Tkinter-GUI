# Software Lab 

## Python Datascience Assignment
Problem statement: [here](https://github.com/dasabir/CS29006_SW_Lab_Spr2022/blob/master/Python_DS_Assignment/)

## Authors
ROUNAK SAHA
20CS30043

