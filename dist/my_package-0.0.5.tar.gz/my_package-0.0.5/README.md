# Software Lab 

## Python Tkinter Assignment
Problem statement: [here](https://github.com/dasabir/CS29006_SW_Lab_Spr2022/tree/master/Python_Tkinter_Assignment)

## Latest(and recommended) version of my_package
0.0.5

## Authors
ROUNAK SAHA
20CS30043

